import UIKit
import Combine

var cancellables = Set<AnyCancellable>()

enum ExampleError: Swift.Error {
    case somethingWentWrong
}

let weatherPublisher = PassthroughSubject<Int, ExampleError>()

let weatherSubscriber = weatherPublisher.filter( {  $0 > 15 })
    .sink { print($0) } receiveValue: { value in
        print("Temperature: \(value) celsius")
    }
    .store(in: &cancellables)
weatherPublisher.send(23)
weatherPublisher.send(12)
weatherPublisher.send(32)
weatherPublisher.send(completion: Subscribers.Completion<ExampleError>.failure(ExampleError.somethingWentWrong))
weatherPublisher.send(16)
